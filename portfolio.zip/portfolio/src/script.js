document.getElementById('submit-recommendation-btn').addEventListener('click', function() {
  var recommendationText = document.getElementById('new-recommendation-text').value;

  if (recommendationText !== '') {
    // Create a new recommendation element
    var newRecommendation = document.createElement('div');
    newRecommendation.classList.add('recommendation');
    newRecommendation.innerHTML = `<p>"${recommendationText}"</p><p>- New Reviewer</p>`;

    // Add the new recommendation to the list
    document.getElementById('recommendation-list').appendChild(newRecommendation);

    // Clear the textarea after submission
    document.getElementById('new-recommendation-text').value = '';
  }
});
document.getElementById("recommendation-form").addEventListener("submit", function(event) {
  event.preventDefault(); // Prevent the default form submission

  // Add the new recommendation to the list
  let recommendationText = document.getElementById("recommendation-input").value;
  if (recommendationText) {
    let recommendationList = document.getElementById("recommendation-list");
    let newRecommendation = document.createElement("p");
    newRecommendation.textContent = recommendationText;
    recommendationList.appendChild(newRecommendation);
    
    // Show the pop-up confirmation message
    showPopUp("Thank you for submitting a recommendation!");
    
    // Clear the input field
    document.getElementById("recommendation-input").value = "";
  }
});

// Function to show the pop-up
function showPopUp(message) {
  let popUp = document.createElement("div");
  popUp.className = "popup";
  popUp.textContent = message;
  document.body.appendChild(popUp);

  // Remove the pop-up after 3 seconds
  setTimeout(() => {
    popUp.remove();
  }, 3000);
}
